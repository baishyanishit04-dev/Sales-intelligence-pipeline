import pytest

from src.pipeline.nodes import (
    validate_company_input,
    is_data_sparse,
    get_fallback_signals,
    run_pipeline,
)


def test_validate_company_input_strips_whitespace():
    assert validate_company_input("  Acme Corp  ") == "Acme Corp"


def test_validate_company_input_rejects_empty():
    with pytest.raises(ValueError):
        validate_company_input("   ")


def test_is_data_sparse_true_for_no_articles():
    assert is_data_sparse([]) is True


def test_is_data_sparse_false_when_articles_present():
    assert is_data_sparse([{"title": "x"}]) is False


def test_fallback_signals_mention_company():
    signals = get_fallback_signals("Widget LLC")
    assert any("Widget LLC" in s for s in signals)


def test_run_pipeline_known_company_uses_live_path():
    result = run_pipeline("Acme Corp")
    assert result.used_fallback is False
    assert len(result.articles) > 0
    assert result.briefing

def test_run_pipeline_unknown_company_uses_fallback():
    result = run_pipeline("Totally Unknown Startup 123")
    assert result.used_fallback is True
    assert result.briefing
