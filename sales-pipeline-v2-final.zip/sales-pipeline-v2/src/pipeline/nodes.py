"""
Sales Intelligence Pipeline — Python reference implementation.

Mirrors the 5-node n8n workflow in n8n-workflow/sales-intelligence-pipeline.json:

    1. Company Input      -> validate_company_input()
    2. Live News Fetch    -> fetch_news()
    3. Fallback Logic     -> is_data_sparse() / get_fallback_signals()
    4. LLM Briefing       -> generate_briefing()
    5. Output             -> run_pipeline() returns the final dict

This module works in two modes:
  - LIVE mode: set NEWSAPI_KEY and (GEMINI_API_KEY or ANTHROPIC_API_KEY) env vars
    to hit real APIs.
  - MOCK mode (default, no keys required): uses local sample data so the
    pipeline can be run and tested without network access or API keys.
"""

from __future__ import annotations

import os
import json
from dataclasses import dataclass, field
from typing import Any


NEWSAPI_KEY = os.environ.get("NEWSAPI_KEY")
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")

DATA_SPARSE_THRESHOLD = 1  # fewer than this many articles counts as "data-sparse"


@dataclass
class PipelineResult:
    company: str
    articles: list[dict[str, Any]] = field(default_factory=list)
    used_fallback: bool = False
    briefing: str = ""
    source_mode: str = "mock"


# ---------------------------------------------------------------------------
# Node 1: Company Input
# ---------------------------------------------------------------------------
def validate_company_input(company_name: str) -> str:
    """Basic validation/normalization of the input node."""
    if not company_name or not company_name.strip():
        raise ValueError("company_name must be a non-empty string")
    return company_name.strip()


# ---------------------------------------------------------------------------
# Node 2: Live News Fetch
# ---------------------------------------------------------------------------
def fetch_news(company_name: str) -> list[dict[str, Any]]:
    """
    Fetch recent news articles about the company.

    LIVE mode: calls NewsAPI (https://newsapi.org) if NEWSAPI_KEY is set.
    MOCK mode: returns deterministic sample data so the pipeline is
    testable offline. Real deployments should replace this with a live
    call (NewsAPI, Bing News, or similar).
    """
    if NEWSAPI_KEY:
        import requests  # local import so the package is optional in mock mode

        resp = requests.get(
            "https://newsapi.org/v2/everything",
            params={
                "q": company_name,
                "sortBy": "publishedAt",
                "pageSize": 5,
                "apiKey": NEWSAPI_KEY,
            },
            timeout=8,
        )
        resp.raise_for_status()
        return resp.json().get("articles", [])

    # MOCK mode — deterministic sample so tests don't depend on network state.
    # "zepto" entries below are real, current headlines (paraphrased from public
    # reporting, Sept 2026) — included so a demo run shows the pipeline handling
    # genuine information, not placeholder text. Everything else falls back to
    # the data-sparse branch, same as an unknown company would in live mode.
    sample_db = {
        "acme corp": [
            {"title": "Acme Corp announces Q3 earnings beat", "publishedAt": "2026-08-01"},
            {"title": "Acme Corp expands into APAC market", "publishedAt": "2026-07-15"},
        ],
        "zepto": [
            {
                "title": "Zepto postpones IPO by two to three quarters, targets Feb-May 2027 listing",
                "publishedAt": "2026-08-01",
            },
            {
                "title": "Zepto closes pre-IPO private placement raising over Rs 1,000 crore ahead of planned listing",
                "publishedAt": "2026-08-01",
            },
            {
                "title": "Zepto daily order volumes reach 2.33 million with ~48 million annual transacting users as of March 2026",
                "publishedAt": "2026-08-03",
            },
            {
                "title": "Zepto operates 1,139 dark stores across 66 cities, mature stores running at 6-7% EBITDA margin",
                "publishedAt": "2026-08-03",
            },
        ],
    }
    return sample_db.get(company_name.lower(), [])  # unknown companies -> data-sparse


# ---------------------------------------------------------------------------
# Node 3: Fallback Logic (for data-sparse firms)
# ---------------------------------------------------------------------------
def is_data_sparse(articles: list[dict[str, Any]]) -> bool:
    return len(articles) < DATA_SPARSE_THRESHOLD


def get_fallback_signals(company_name: str) -> list[str]:
    """
    When live news is too thin to brief on, fall back to lower-frequency
    but still useful public signals. In a real deployment this could
    call a company-registry API, LinkedIn, or a firmographic data vendor.
    Kept as static placeholders here since those APIs require paid keys.
    """
    return [
        f"No recent (last-30-day) news coverage found for '{company_name}'.",
        "Consider checking company registry filings, LinkedIn updates, or the company's own press page.",
        "Fallback signal: treat as an early-stage / low-media-footprint account.",
    ]


# ---------------------------------------------------------------------------
# Node 4: LLM Briefing
# ---------------------------------------------------------------------------
def generate_briefing(company_name: str, signals: list[Any], used_fallback: bool) -> str:
    """
    Summarize the gathered signals into a short sales briefing.

    LIVE mode: calls Gemini if GEMINI_API_KEY is set, else Anthropic's
    Claude if ANTHROPIC_API_KEY is set.
    MOCK mode: produces a deterministic, template-based briefing so the
    pipeline runs end-to-end without any API key.
    """
    prompt = (
        f"Write a concise 3-bullet sales briefing for {company_name} using these "
        f"signals: {json.dumps(signals)}"
    )

    if GEMINI_API_KEY:
        import requests

        resp = requests.post(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent",
            params={"key": GEMINI_API_KEY},
            json={"contents": [{"parts": [{"text": prompt}]}]},
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()["candidates"][0]["content"]["parts"][0]["text"]

    if ANTHROPIC_API_KEY:
        import requests

        resp = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={
                "x-api-key": ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01",
                "content-type": "application/json",
            },
            json={
                "model": "claude-sonnet-4-6",
                "max_tokens": 300,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()["content"][0]["text"]

    # MOCK mode
    bullets = signals if used_fallback else [a.get("title", "") for a in signals]
    bullets = bullets[:3] or ["No signal data available."]
    return "\n".join(f"- {b}" for b in bullets)


# ---------------------------------------------------------------------------
# Node 5: Output — orchestrates the full pipeline
# ---------------------------------------------------------------------------
def run_pipeline(company_name: str) -> PipelineResult:
    name = validate_company_input(company_name)
    articles = fetch_news(name)

    used_fallback = is_data_sparse(articles)
    signals: list[Any] = get_fallback_signals(name) if used_fallback else articles

    briefing = generate_briefing(name, signals, used_fallback)

    mode = "live" if (NEWSAPI_KEY or GEMINI_API_KEY or ANTHROPIC_API_KEY) else "mock"
    return PipelineResult(
        company=name,
        articles=articles,
        used_fallback=used_fallback,
        briefing=briefing,
        source_mode=mode,
    )


if __name__ == "__main__":
    import sys

    company = sys.argv[1] if len(sys.argv) > 1 else "Acme Corp"
    result = run_pipeline(company)
    print(json.dumps(result.__dict__, indent=2, default=str))
