# Sales Intelligence Pipeline

A 5-node workflow that turns a company name into a short, LLM-written sales
briefing — pulling recent news, falling back to alternative signals when a
company has little media coverage, and summarizing it into 3 bullets a rep
can read before a call.

Available both as an importable **n8n workflow** and as a **runnable Python
reference implementation**.

## The 5 nodes

| Node | Where | Job |
|---|---|---|
| 1. Company Input | `validate_company_input()` | Cleans/validates the input |
| 2. Live News Fetch | `fetch_news()` | Calls NewsAPI for recent articles |
| 3. Fallback Logic | `is_data_sparse()` / `get_fallback_signals()` | Switches to fallback guidance if too few articles come back |
| 4. LLM Briefing | `generate_briefing()` | Summarizes into 3 bullets via Gemini or Claude |
| 5. Output | `run_pipeline()` | Returns the final structured result |

## Why two versions of the pipeline?

`n8n-workflow/sales-intelligence-pipeline.json` is a real, importable n8n
workflow — import it into an n8n instance and wire up your own API
credentials. `src/pipeline/nodes.py` is the same 5-node logic in plain
Python, so it can be run and tested without an n8n installation.

## Quickstart

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Mock mode — runs immediately, no API keys needed
python3 -m src.pipeline.nodes "Acme Corp"

# Run tests
pytest tests/ -v
```

## Running with real, live data

Copy `.env.example` to `.env` and set:

- `NEWSAPI_KEY` — get a free key at newsapi.org (100 requests/day, no card
  required; free tier is for development/testing, not production, and
  articles are delayed ~24h)
- `GEMINI_API_KEY` — get a free key at aistudio.google.com/apikey (no
  billing required for the Flash models)
- or `ANTHROPIC_API_KEY` — get a key at console.anthropic.com (no free
  tier; requires billing)

Then export those variables (or use a tool like `python-dotenv`) before
running the same command above — the pipeline automatically switches from
mock mode to live mode once it detects a key.

## How the fallback logic works

If live news search returns fewer than `DATA_SPARSE_THRESHOLD` articles
(default: 1), the pipeline branches to a fallback path that surfaces
lower-frequency public signals instead of returning an empty briefing —
useful for small or private companies with little media coverage. This
mirrors node 3 in the n8n workflow.

## License

MIT — see `LICENSE`.
